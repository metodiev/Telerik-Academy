﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustBelot.Common
{
    public class GameManager
    {
        private List<Card> Deck;

        public GameManager()
        {
            
        }

        public StartNewGame()
        {
            // TODO: prepare deck
            // TODO: shuffle
        }
    }
}
