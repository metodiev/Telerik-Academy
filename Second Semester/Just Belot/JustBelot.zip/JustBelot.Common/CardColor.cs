﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustBelot.Common
{
    public enum CardColor
    {
        Spades = 0,
        Heart = 1,
        Club = 2,
        Diamond = 3,
    }
}
