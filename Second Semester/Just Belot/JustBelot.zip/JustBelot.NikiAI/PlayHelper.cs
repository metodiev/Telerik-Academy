﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustBelot.NikiAI
{
    internal class PlayHelper
    {
        internal void MakeDecision()
        {
            //
        }
    }
}
